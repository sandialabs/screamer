#include<iostream>
#include<string.h>
using namespace std;

extern "C" {void zdem_(char*, int&);} 
//extern "C" {void writebuffer_(char*, int&);} 

extern "C" {
	void writebuffer_(char *string, int strlen){
	char* newString = new char[strlen+1];
        for(int i=0;i<strlen;i++){
                 newString[i]=string[i];
        }
        newString[strlen]='\0';
	cout<<newString<<endl;
	}
}

int main(int argc,char *argv[]){
	char inpfile[256];
	int clen;
	cout<<"\n\nFortran subroutine Screamer called from C \n";
	cout<<argv[0]<<" ";
	cout <<argc<<endl;
	if(argc<2){
		cout<<"Enter run file name: ";
		cin>>inpfile;
		clen=strlen(inpfile);
		zdem_(inpfile,clen);
	}else{
		clen=strlen(argv[1]);
		zdem_(argv[1],clen);
		
	}		
	//clen=strlen(inpfile);
	//cout<<inpfile<<endl;
	//zdem_(inpfile, clen);
	return 0;
	
}
